def gui_export(full_object):
    print("gui_export is not supported. Instead, store it in a global variable named `full_object`.")
